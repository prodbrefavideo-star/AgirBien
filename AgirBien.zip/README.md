# AI-Musulmane

Projet React + Vite : assistant musulman pour conseils spirituels (Q/A, moteur d'intention, rappels).

## Instructions rapides

1. Installer les dépendances : `npm install`
2. Lancer en dev : `npm run dev`
3. Construire : `npm run build`
4. Preview : `npm run preview`

Pour déployer (recommandé) : push sur GitHub puis importer le repo sur Vercel (voir instructions dans le chat).
